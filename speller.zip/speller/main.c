#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<ctype.h>

#include"GTrie.h"

#define MAXWORDSIZE 50

// this function was made to ignore the case of letters 
// and to allow a non-alphabit charachter to be at the beginning
// or the at end of each word, like "(word" or "word,"  
//
// this function allocates MAXWORDSIZE bytes of memeory in each call
// so don't froget to free() the returned pointer
// after finishing working with it
char* ignoreCase(const char *word)
{
	char *tmp = malloc(MAXWORDSIZE*sizeof(char));
	
	int i;
	if(!isalpha(word[0]) && isalpha(word[1]))
	{	
		for (i = 0; word[i] ; i++)
			tmp[i] = tolower(word[i+1]);
			
		if(i >= 3 && !isalpha(tmp[i-2]) && isalpha(tmp[i-3]))
			tmp[i-2] = '\0';
	}	
	else
	{
		for (i = 0; word[i] ; i++)
		{
			tmp[i] = tolower(word[i]);
		}
		
		tmp[i] = '\0';
		
		if(i >= 2 && !isalpha(tmp[i-1]) && isalpha(tmp[i-2]))
			tmp[i-1] = '\0';
	}
	
	return tmp;
}

int main (int argc, char *argv[])
{
	if(argc != 3 && argc != 4)
	{
		printf("Usage: ./speller <dictionary file> <input file> (optionally <output file>)\n");
		return 1;
	}
	
	
	FILE *dict = fopen(argv[1], "r");
	if(!dict)
	{
		printf("could not open %s", argv[1]);
		return 2;
	}
	
	FILE *input = fopen(argv[2], "r");
	if (!input)
	{
		printf("could not open %s", argv[2]);
		return 3;
	}
	
	FILE *output = NULL;
	if(argc == 4)
	{
		output = fopen(argv[3], "w");
		if(!output)
		{
			printf("could not open %s", argv[3]);
			return 4;
		}
	}
	
	
	GTrie *myTrie = calloc(1, sizeof(GTrie));
	
	char word[MAXWORDSIZE];
	
	while(!feof(dict))
	{
		fscanf(dict, "%s", word);
		load(myTrie, word);
	}
	printf("Done loading ^_^\n");
	
	if(!output)
			printf("Mispelled words:\n");
		else
			fprintf(output, "Mispelled words:\n");
	
	while(!feof(input))
	{
		fscanf(input, "%s", word);
		char *tmp = ignoreCase(word);
		if(!contains(myTrie, tmp))
		{
			if(!output)
				printf("%s  ", word);
			else
				fprintf(output, "%s\n", word);
		}
		free(tmp);
	}
	printf("\nDone spelling ^_^\n");
	
		
	unload(myTrie);
	fclose(dict);
	fclose(input);
	if(output)
		fclose(output);
	return 0;
}


